const BlePkg = require('./BlePkg');

const ms = 1000;

/**
	@params data 입력받은 센서 데이터
	@params updateValue 블루투스로 전송할 데이터
		=> 8Bit Data만 가능!(0 ~ 255)
*/
const Callback = (data, updateValue)=>{
	console.log(data);
	updateValue(parseInt(data.Temp));
}

/**
	@params Callback
	@params ms Process가 동작할 주기
*/
BlePkg.registProcess( Callback, ms );
